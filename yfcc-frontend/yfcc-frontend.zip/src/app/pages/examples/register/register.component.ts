import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-register",
  templateUrl: "register.component.html"
})
export class RegisterComponent implements OnInit {
  focus;
  focus1;
  focus2;
  constructor() {}

  ngOnInit() {}
}
